create database if not exists project;
use project;
create table  if not exists final_project_data (
show_id varchar(50),
type varchar(20),
title text,
director text,
cast text,
date_added text,
release_year int,
rating varchar(10),
duration varchar(20),
listed_in text,
description text
);
-- 1.Display all records 
select * from final_project_data;
-- it display all dataset. 
-- 2.Count the total number of titles available.
select count(*) as total_titles from final_project_data;
-- it shows total rows count.
-- 3.Display only the title and type columns.
select title, type from final_project_data;
-- it show the title and type only
-- 4.Show all Movies in the dataset.
select * from final_project_data where type = 'movie';
-- it show movie only
-- 5.Show all TV Shows in the dataset.
select * from final_project_data where type = 'tv show';
-- it display 'tv shows'.
-- 6.Show all titles released in 2020.
select * from final_project_data where release_year = '2020';
-- it display the which title release in 2020.
-- 7.Display content produced in India.
select * from final_project_data where country like '%india%';
-- it display how many contents in india.
-- 8.Show titles with rating TV-MA.
select * from final_project_data where rating = 'TV-MA';
-- it display rating.
-- 9.Display titles added to Netflix in 2021.
select * from final_project_data where date_added like '%2021%';
-- it display the titles added in 2021.
-- 10.	Show movies released after 2018.
select * 
from final_project_data 
where type = 'movie' 
and release_year > 2018;
-- it display the movie which release after in 2018.
-- 11.	Count the number of Movies and TV Shows.
select type, count(*) as total_titles 
from final_project_data
group by type;
-- it display the count of movies and tv shows.
-- 12.Find the most common rating.
select rating, count(*) as count 
from final_project_data
group by rating
order by count desc
limit 1;
-- 13.Find the total number of titles per country.
select country, count(*)
from final_project_data
group by country;
-- 14.Find the number of titles released each year.
select release_year,count(*)
from final_project_data
group by release_year
order by release_year;
-- 15.Find the top 5 countries producing content.
select country, count(*) as total
from final_project_data
group by country
order by total desc
limit 5;
-- 16.Show titles ordered by release year (latest first).
select * from final_project_data
order by release_year desc;
-- 17.Show the top 10 newest titles.
select * from final_project_data
order by release_year desc
limit 10;
-- 18.Show directors with the highest number of titles.
select director, count(*) as total
from final_project_data
where director is not null
group by director 
order by total desc;
-- 19.Find the longest movie.
select * from final_project_data
where type = 'movie'
order by cast(replace(duration,'min','')as unsigned) desc
limit 1;
-- 20.Find movies with duration greater than 120 minutes.
select * from final_project_data
where type ='movie'
and cast(replace(duration,'min','')as unsigned)>120;
-- 21.Find titles that do not have a director listed.
select * from final_project_data
where director is null or director ='';
-- all titles is the dataset contain director infromation.No records were found where the director field is null or empty. 
-- 22.Find the top 10 genres on Netflix.
select listed_in ,count(*)as total
from final_project_data
group by listed_in
order by total desc
limit 10;
-- 23.Find how many titles each director created.
select director,count(*)
from final_project_data
group by director;
-- 24.Find the year with the most content releases.
select release_year,count(*) as total
from final_project_data
group by release_year
order by total desc 
limit 1;
-- 25.Find the country producing the most TV Shows.
select country,count(*) as total from final_project_data
group by country
order by total desc 
limit 1;
-- 26.Find average release year of movies.
select avg(release_year)from final_project_data where type = 'movie';
-- 27.Find the number of titles added each year.Students must write SQL queries and explain insights.
select right(date_added,4)as year,count(*) from final_project_data
group by year;
-- 28.Find top 5 directors with most content
select * from final_project_data 
where release_year >= year(curdate())-5;
-- 29.Which type of content is most common on Netflix?
select type, count(*)
from final_project_data group by type
order by count(*) desc;
-- 30.Which country produces the most Netflix content?
select country,count(*)
from final_project_data group by country
order by count(*) desc limit 1;
-- 31.Which year had the highest number of releases?
select release_year,count(*) from final_project_data
group by release_year order by count(*) desc limit 1;
-- 32.Which director created the most content?
select director,count(*) as total_titles
from final_project_data
where director is not null and director<>''
group by director order by total_titles desc
limit 1;
-- 33.Which genre appears most frequently?
select listed_in,count(*) as total from final_project_data
group by listed_in order by total desc limit 1;
-- 34.Find movies released in the last 5 years.
select * from final_project_data where type = 'movie'
and release_year >= year(curdate()) -5;
-- 35.Find titles where duration is more than 2 hours.
select title,duration from final_project_data
where type = 'movie' and cast(replace(duration,'min','') as unsigned) > 120;
-- 36.Find directors who created both Movies and TV Shows.
select director from final_project_data
where director is not null and director <>''
group by director having count(distinct type)>1;
-- 37.Find countries with more than 50 titles.
select country,count(*)as total_titles
from final_project_data where country is not null and country <>''
group by country having count(*)>50;
-- no country in this dataset has more than 50 titles,so the query returns 0 rows
-- 38.Find titles added in the same year they were released.
select title,release_year,date_added
from final_project_data
where release_year = right(date_added,4); 
-- 39.Find oldest movie in the dataset.
select * from final_project_data where type = 'movie'
order by release_year asc limit 1;
-- 40.Find top 5 years with highest releases.
select release_year,count(*) as total_tiles
from final_project_data group by release_year
order by total_tiles desc limit 5;